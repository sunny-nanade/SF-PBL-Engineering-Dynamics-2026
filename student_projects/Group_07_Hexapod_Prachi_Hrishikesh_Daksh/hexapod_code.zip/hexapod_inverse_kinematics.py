"""
=========================================================
  MODULE 2: INVERSE KINEMATICS
  Given a desired foot position (x, y, z), computes
  the three joint angles using geometric decomposition.

  Conversion of hexapod_inverse_kinematics.m
=========================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from typing import Tuple
from hexapod_params import HexapodParams


def solve_ik(px: float, py: float, pz: float,
             L1: float, L2: float, L3: float
             ) -> Tuple[float, float, float, bool]:
    """
    Geometric IK solver for a 3-DOF hexapod leg.

    Parameters
    ----------
    px, py, pz : desired foot position [m] relative to hip
    L1, L2, L3 : coxa, femur, tibia lengths [m]

    Returns
    -------
    t1, t2, t3 : joint angles [degrees]
    valid      : True if target is reachable
    """

    # Step 1 — Coxa angle from top-down view
    t1 = np.degrees(np.arctan2(py, px))

    # Step 2 — Project into the 2-D leg plane (subtract coxa offset)
    r = np.sqrt(px**2 + py**2) - L1
    z = pz
    D = np.sqrt(r**2 + z**2)   # femur-base → foot distance

    # Step 3 — Reachability check
    if D > (L2 + L3) or D < abs(L2 - L3):
        print(f"  WARNING: Target ({px:.3f}, {py:.3f}, {pz:.3f}) out of reach! "
              f"D={D:.4f}, max={L2+L3:.4f}")
        return 0.0, 0.0, 0.0, False

    # Step 4 — Tibia angle (law of cosines), negative = knee bends down
    cos_t3 = (D**2 - L2**2 - L3**2) / (2 * L2 * L3)
    cos_t3 = np.clip(cos_t3, -1.0, 1.0)   # numerical safety
    t3 = -np.degrees(np.arccos(cos_t3))

    # Step 5 — Femur angle
    alpha = np.degrees(np.arctan2(z, r))
    beta  = np.degrees(np.arctan2(L3 * np.sin(np.radians(-t3)),
                                   L2 + L3 * np.cos(np.radians(-t3))))
    t2 = alpha + beta

    return t1, t2, t3, True


def reconstruct_leg_points(t1: float, t2: float, t3: float,
                            L1: float, L2: float, L3: float) -> np.ndarray:
    """
    Returns 4x3 array of joint positions: [origin, J1, J2, foot]
    for visualising the IK solution.
    """
    O  = np.zeros(3)
    J1 = np.array([L1 * np.cos(np.radians(t1)),
                   L1 * np.sin(np.radians(t1)),
                   0.0])
    J2 = J1 + np.array([L2 * np.cos(np.radians(t1)) * np.cos(np.radians(t2)),
                         L2 * np.sin(np.radians(t1)) * np.cos(np.radians(t2)),
                         L2 * np.sin(np.radians(t2))])
    J3 = J2 + np.array([L3 * np.cos(np.radians(t1)) * np.cos(np.radians(t2 + t3)),
                         L3 * np.sin(np.radians(t1)) * np.cos(np.radians(t2 + t3)),
                         L3 * np.sin(np.radians(t2 + t3))])
    return np.array([O, J1, J2, J3])


def run_inverse_kinematics(params: HexapodParams):
    L1, L2, L3 = params.L1, params.L2, params.L3

    print("\n--- INVERSE KINEMATICS ---")

    # Same test targets as MATLAB
    targets = [
        ( 0.15,  0.00, -0.05),
        ( 0.12,  0.05, -0.08),
        ( 0.10, -0.04, -0.03),
        ( 0.18,  0.02, -0.10),
    ]

    header = (f"{'Px(m)':>8} {'Py(m)':>8} {'Pz(m)':>8} | "
              f"{'t1(deg)':>8} {'t2(deg)':>8} {'t3(deg)':>8} | Valid")
    print(header)
    print("-" * 62)

    for px, py, pz in targets:
        t1, t2, t3, valid = solve_ik(px, py, pz, L1, L2, L3)
        v = "YES" if valid else "NO"
        print(f"{px:>8.3f} {py:>8.3f} {pz:>8.3f} | "
              f"{t1:>8.2f} {t2:>8.2f} {t3:>8.2f} | {v}")

    # ---- Visualise IK solution for first target ----
    px0, py0, pz0 = 0.15, 0.00, -0.05
    t1, t2, t3, _ = solve_ik(px0, py0, pz0, L1, L2, L3)
    pts = reconstruct_leg_points(t1, t2, t3, L1, L2, L3)

    fig = plt.figure(figsize=(7, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(pts[:, 0], pts[:, 1], pts[:, 2],
            'b-o', linewidth=3, markersize=8, label='Leg segments')
    ax.scatter([px0], [py0], [pz0], c='red', s=120, marker='*',
               zorder=5, label='Target foot position')
    ax.set_title(f"IK Solution: θ₁={t1:.1f}°, θ₂={t2:.1f}°, θ₃={t3:.1f}°")
    ax.set_xlabel("X (m)"); ax.set_ylabel("Y (m)"); ax.set_zlabel("Z (m)")
    ax.legend()
    ax.view_init(elev=20, azim=30)
    plt.tight_layout()
    print("  -> IK visualization ready.")
