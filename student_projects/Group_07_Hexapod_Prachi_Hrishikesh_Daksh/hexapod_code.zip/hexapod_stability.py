"""
=========================================================
  MODULE 5: STABILITY ANALYSIS
  Computes the Static Stability Margin (SSM) — minimum
  distance from CoM projection to the support polygon edge.

  Conversion of hexapod_stability.m
=========================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull


def point_to_segment_distance(P: np.ndarray,
                               A: np.ndarray,
                               B: np.ndarray) -> float:
    """
    Shortest distance from point P to line segment AB (2-D).
    Equivalent to the nested function in MATLAB script.
    """
    AB = B - A
    AP = P - A
    t  = np.dot(AP, AB) / (np.dot(AB, AB) + 1e-12)
    t  = np.clip(t, 0.0, 1.0)
    closest = A + t * AB
    return float(np.linalg.norm(P - closest))


def static_stability_margin(com: np.ndarray,
                              foot_positions: np.ndarray) -> tuple:
    """
    Compute SSM and whether CoM is inside the support polygon.

    Parameters
    ----------
    com            : (2,) array, CoM projected to ground [x, y]
    foot_positions : (N, 2) array, grounded foot positions

    Returns
    -------
    ssm    : float, minimum distance to polygon edge
    inside : bool
    hull_pts : ordered polygon vertices
    """
    hull    = ConvexHull(foot_positions)
    hull_pts = foot_positions[np.append(hull.vertices, hull.vertices[0])]

    # Minimum distance from CoM to any hull edge
    ssm = np.inf
    for i in range(len(hull_pts) - 1):
        d = point_to_segment_distance(com, hull_pts[i], hull_pts[i + 1])
        ssm = min(ssm, d)

    # Check if CoM is inside convex hull
    from matplotlib.path import Path
    path   = Path(hull_pts)
    inside = bool(path.contains_point(com))

    return ssm, inside, hull_pts


def run_stability_analysis(params=None):
    """
    Run stability analysis for all 6 hexapod feet.

    If params (HexapodParams) is provided, foot positions are computed
    from the robot geometry.  Otherwise defaults matching the original
    MATLAB tripod are used (legacy mode).
    """
    print("\n--- STABILITY ANALYSIS ---\n")

    com = np.array([0.0, 0.0])

    # ---- Compute all 6 foot positions from params ----
    if params is not None:
        from hexapod_inverse_kinematics import solve_ik
        leg_labels = params.leg_names           # FR, MR, RR, FL, ML, RL
        foot_positions = np.zeros((6, 2))
        foot_z = np.zeros(6)
        print("Computing foot positions from hexapod geometry:")
        for i, leg in enumerate(leg_labels):
            mount_rad = np.radians(params.leg_angles[i])
            cx = np.cos(mount_rad)
            cy = np.sin(mount_rad)
            # Standing foot position in hip frame
            px = params.foot_reach * cx
            py = params.foot_reach * cy
            pz = -params.body_height
            # Project to world frame (body frame = world frame at spawn)
            foot_positions[i] = [px, py]
            foot_z[i] = pz
            print(f"  {leg} (F{i+1}): mount={params.leg_angles[i]:.0f}°  "
                  f"pos=({px:.3f}, {py:.3f}, {pz:.3f})")
    else:
        # Legacy: MATLAB tripod Group A (3 feet only)
        foot_positions = np.array([
            [ 0.18,  0.08],   # FR foot
            [-0.16,  0.09],   # RR foot
            [ 0.00, -0.18],   # ML foot
        ])
        leg_labels = ['FR', 'RR', 'ML']

    n_feet = len(foot_positions)
    print(f"\nSupport polygon vertices ({n_feet} feet):")
    for i, f in enumerate(foot_positions):
        label = f"F{i+1} ({leg_labels[i]})" if params else f"F{i+1}"
        print(f"  {label}: ({f[0]:.3f}, {f[1]:.3f})")

    ssm, inside, hull_pts = static_stability_margin(com, foot_positions)

    print(f"\nStatic Stability Margin (SSM): {ssm:.4f} m")
    status = "STABLE ✓ (CoM inside support polygon)" if inside \
             else "UNSTABLE ✗ (CoM outside support polygon)"
    print(f"Status: {status}")

    # ---- Visualise ----
    fig, axes = plt.subplots(1, 2, figsize=(13, 6))

    # Left: main support polygon with ALL feet
    ax = axes[0]
    ax.set_aspect('equal')
    ax.grid(True)
    ax.set_title("Support Polygon & Stability Margin (All 6 Feet)")
    ax.set_xlabel("X (m)"); ax.set_ylabel("Y (m)")

    # Draw the convex hull (support polygon)
    poly = plt.Polygon(hull_pts[:-1], closed=True,
                       facecolor=(0.7, 0.9, 0.7), edgecolor='green',
                       alpha=0.5, linewidth=2, label='Support polygon')
    ax.add_patch(poly)

    # Draw all feet with distinct colours
    colors_feet = plt.cm.tab10(np.linspace(0, 1, n_feet))
    for i, f in enumerate(foot_positions):
        label = f"F{i+1} ({leg_labels[i]})" if params else f"F{i+1}"
        ax.scatter(f[0], f[1], s=130, c=[colors_feet[i]], marker='s',
                   zorder=5, edgecolors='black', linewidth=0.8)
        ax.annotate(label, xy=f,
                    xytext=(f[0] + 0.008, f[1] + 0.012),
                    fontsize=9, fontweight='bold', color=colors_feet[i])

    # Draw connecting lines between adjacent feet (visual only)
    for i in range(n_feet):
        j = (i + 1) % n_feet
        ax.plot([foot_positions[i, 0], foot_positions[j, 0]],
                [foot_positions[i, 1], foot_positions[j, 1]],
                'k--', linewidth=0.6, alpha=0.4)

    # CoM marker
    ax.scatter(*com, s=180, c='red', marker='*', zorder=6)
    ax.annotate("CoM", xy=com, xytext=(com[0] + 0.008, com[1] + 0.012),
                fontsize=10, fontweight='bold', color='red')

    # SSM circle
    theta_c = np.linspace(0, 2 * np.pi, 200)
    ax.plot(com[0] + ssm * np.cos(theta_c),
            com[1] + ssm * np.sin(theta_c),
            'r--', linewidth=1.5, label=f"SSM = {ssm:.4f} m")
    ax.legend(loc='best')

    # Right: gait comparison bar chart
    ax2 = axes[1]
    if params is not None:
        # Compute tripod groups from actual geometry
        fp_tripod_a = foot_positions[[0, 2, 4]]  # FR, RR, ML (indices 0,2,4)
        fp_tripod_b = foot_positions[[1, 3, 5]]  # MR, FL, RL (indices 1,3,5)
        configurations = {
            "Tripod A\n(FR,RR,ML)": fp_tripod_a,
            "Tripod B\n(MR,FL,RL)": fp_tripod_b,
            "All 6 feet": foot_positions,
        }
    else:
        configurations = {
            "Tripod A":  np.array([[ 0.18, 0.08], [-0.16, 0.09], [ 0.00,-0.18]]),
            "Tripod B":  np.array([[-0.18,-0.08], [ 0.16,-0.09], [ 0.00, 0.18]]),
            "Quad (4)":  np.array([[ 0.18, 0.08], [-0.16, 0.09], [-0.18,-0.08], [ 0.16,-0.09]]),
            "Penta (5)": np.array([[ 0.18, 0.08], [-0.16, 0.09], [ 0.00,-0.18], [-0.18,-0.08], [ 0.16,-0.09]]),
        }

    print("\n--- Gait Stability Comparison ---")
    print(f"{'Gait':<16} {'Legs':<6} {'SSM (m)':<8}")
    print("-" * 30)

    names, margins = [], []
    for cfg_name, fp in configurations.items():
        if len(fp) >= 3:
            m, ins, _ = static_stability_margin(com, fp)
        else:
            m = 0.0
        names.append(cfg_name)
        margins.append(m)
        print(f"{cfg_name:<16} {len(fp):<6} {m:.4f}")

    bar_colors = ['steelblue' if m > 0.05 else 'tomato' for m in margins]
    ax2.bar(names, margins, color=bar_colors, edgecolor='black')
    ax2.set_title("Stability Margin by Gait Configuration")
    ax2.set_ylabel("SSM (m)")
    ax2.axhline(0, color='black', linewidth=0.8)
    ax2.grid(axis='y', alpha=0.5)
    for i, v in enumerate(margins):
        ax2.text(i, v + 0.002, f"{v:.3f}", ha='center', fontsize=9)

    plt.tight_layout()
    print("\n  -> All 6 feet shown on support polygon")
    print("  -> More stance legs = larger stability margin")
    print("  -> Stability plot ready.")
