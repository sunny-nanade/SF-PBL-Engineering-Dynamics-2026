"""
=========================================================
  HEXAPOD TELEMETRY & ANALYTICS
  Records simulation data and generates a post-run
  dashboard with joint angles, body position, energy,
  power, and stability metrics over time.
=========================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class Telemetry:
    """Collects time-series data during a PyBullet simulation run."""

    params: object = None   # HexapodParams reference

    # Time series
    time: List[float] = field(default_factory=list)
    body_pos: List[tuple] = field(default_factory=list)       # (x, y, z)
    body_euler: List[tuple] = field(default_factory=list)     # (roll, pitch, yaw)

    # Per-leg joint angles (degrees)
    joint_angles: Dict[str, List[tuple]] = field(default_factory=dict)

    # Per-leg joint torques (N·m) — applied motor torque
    joint_torques: Dict[str, List[tuple]] = field(default_factory=dict)

    # Per-leg joint velocities (rad/s)
    joint_velocities: Dict[str, List[tuple]] = field(default_factory=dict)

    # Direction at each timestep
    directions: List[str] = field(default_factory=list)

    def __post_init__(self):
        if self.params is not None:
            for leg in self.params.leg_names:
                self.joint_angles[leg] = []
                self.joint_torques[leg] = []
                self.joint_velocities[leg] = []

    def record(self, t: float, p, robot_id, joint_map, direction: str):
        """Record one timestep of telemetry data."""
        self.time.append(t)
        self.directions.append(direction)

        # Body position and orientation
        pos, orn = p.getBasePositionAndOrientation(robot_id)
        self.body_pos.append(tuple(pos))
        euler = p.getEulerFromQuaternion(orn)
        self.body_euler.append(tuple(np.degrees(e) for e in euler))

        # Joint angles, torques, and velocities
        # PyBullet getJointState returns:
        #   [0] jointPosition, [1] jointVelocity,
        #   [2] jointReactionForces[6], [3] appliedJointMotorTorque
        if self.params is not None:
            for leg in self.params.leg_names:
                angles = []
                torques = []
                velocities = []
                for jt in ['coxa', 'femur', 'tibia']:
                    idx = joint_map.get((leg, jt))
                    if idx is not None:
                        js = p.getJointState(robot_id, idx)
                        angles.append(np.degrees(js[0]))       # position → deg
                        velocities.append(js[1])                # velocity rad/s
                        torques.append(js[3])                   # motor torque N·m
                    else:
                        angles.append(0.0)
                        velocities.append(0.0)
                        torques.append(0.0)
                self.joint_angles[leg].append(tuple(angles))
                self.joint_velocities[leg].append(tuple(velocities))
                self.joint_torques[leg].append(tuple(torques))


# ================================================================== #
#  POWER & ENERGY COMPUTATION
# ================================================================== #

def compute_power_and_energy(telemetry: Telemetry):
    """
    Compute instantaneous power and cumulative energy from telemetry.

    For each joint:  P(t) = |torque * velocity|
    Total power     P_total(t) = sum over all joints
    Cumulative      E(t) = cumulative trapezoidal integral of P_total

    Returns
    -------
    t             : (N,) time array
    power_per_leg : dict  {leg_name: (N,)} array of total leg power
    power_per_type: dict  {'coxa': (N,), 'femur': (N,), 'tibia': (N,)}
    power_total   : (N,)  total robot power
    energy_total  : (N,)  cumulative energy (Joules)
    """
    t = np.array(telemetry.time)
    N = len(t)
    if N < 2:
        return t, {}, {}, np.zeros(N), np.zeros(N)

    joint_types = ['coxa', 'femur', 'tibia']
    leg_names = list(telemetry.joint_torques.keys())

    # Build per-joint-type power arrays
    power_per_type = {jt: np.zeros(N) for jt in joint_types}
    power_per_leg = {}

    for i, leg in enumerate(leg_names):
        torques = np.array(telemetry.joint_torques[leg])   # (N, 3)
        velocities = np.array(telemetry.joint_velocities[leg])  # (N, 3)

        # Mechanical power per joint: P = |tau * omega|
        joint_power = np.abs(torques * velocities)  # (N, 3)

        # Per leg: sum of 3 joints
        leg_total = joint_power.sum(axis=1)  # (N,)
        power_per_leg[leg] = leg_total

        # Accumulate per joint type
        for jt_idx, jt in enumerate(joint_types):
            power_per_type[jt] += joint_power[:, jt_idx]

    # Total power across all legs
    power_total = sum(power_per_leg.values())  # (N,)

    # Cumulative energy via trapezoidal integration
    dt = np.diff(t)
    power_mid = (power_total[:-1] + power_total[1:]) / 2.0
    energy_increments = power_mid * dt
    energy_total = np.zeros(N)
    energy_total[1:] = np.cumsum(energy_increments)

    return t, power_per_leg, power_per_type, power_total, energy_total


# ================================================================== #
#  DASHBOARD PLOTTING
# ================================================================== #

def plot_dashboard(telemetry: Telemetry, save_path: str = "hexapod_dashboard.png"):
    """
    Generate a multi-panel analytics dashboard from recorded telemetry.
    3x3 layout: body state, joint angles, power & energy.
    Saves to the specified file path.
    """
    if len(telemetry.time) < 2:
        print("  Not enough telemetry data to generate dashboard.")
        return

    t = np.array(telemetry.time)
    leg_names = list(telemetry.joint_angles.keys())
    colors = plt.cm.tab10(np.linspace(0, 1, max(len(leg_names), 6)))

    # Compute power & energy
    _, power_per_leg, power_per_type, power_total, energy_total = \
        compute_power_and_energy(telemetry)

    fig, axes = plt.subplots(3, 3, figsize=(18, 14))
    fig.suptitle("Hexapod Simulation Dashboard", fontsize=16, fontweight='bold')

    # ================================================================ #
    #  Row 0: Body state
    # ================================================================ #

    # ---- Panel 1: Body Position (X, Y, Z) ----
    ax = axes[0, 0]
    body_pos = np.array(telemetry.body_pos)
    ax.plot(t, body_pos[:, 0], label='X', linewidth=1)
    ax.plot(t, body_pos[:, 1], label='Y', linewidth=1)
    ax.plot(t, body_pos[:, 2], label='Z', linewidth=1)
    ax.set_title("Body Position")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Position (m)")
    ax.legend(loc='best'); ax.grid(True, alpha=0.3)

    # ---- Panel 2: Body Orientation (roll, pitch, yaw) ----
    ax = axes[0, 1]
    body_euler = np.array(telemetry.body_euler)
    ax.plot(t, body_euler[:, 0], label='Roll', linewidth=1)
    ax.plot(t, body_euler[:, 1], label='Pitch', linewidth=1)
    ax.plot(t, body_euler[:, 2], label='Yaw', linewidth=1)
    ax.set_title("Body Orientation")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Angle (deg)")
    ax.legend(loc='best'); ax.grid(True, alpha=0.3)

    # ---- Panel 3: Body Trajectory (X-Y) ----
    ax = axes[0, 2]
    ax.plot(body_pos[:, 0], body_pos[:, 1], 'b-', linewidth=0.8, alpha=0.7)
    ax.plot(body_pos[0, 0], body_pos[0, 1], 'go', markersize=8, label='Start')
    ax.plot(body_pos[-1, 0], body_pos[-1, 1], 'rs', markersize=8, label='End')
    ax.set_title("Body Trajectory (Top View)")
    ax.set_xlabel("X (m)"); ax.set_ylabel("Y (m)")
    ax.set_aspect('equal'); ax.legend(loc='best'); ax.grid(True, alpha=0.3)

    # ================================================================ #
    #  Row 1: Joint angles
    # ================================================================ #

    # ---- Panel 4: Coxa Angles ----
    ax = axes[1, 0]
    if leg_names:
        for i, leg in enumerate(leg_names):
            data = np.array(telemetry.joint_angles[leg])
            ax.plot(t, data[:, 0], color=colors[i], linewidth=1, label=leg)
    ax.set_title("Coxa Angles")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Angle (deg)")
    ax.legend(loc='best', fontsize=7, ncol=2); ax.grid(True, alpha=0.3)

    # ---- Panel 5: Femur Angles ----
    ax = axes[1, 1]
    if leg_names:
        for i, leg in enumerate(leg_names):
            data = np.array(telemetry.joint_angles[leg])
            ax.plot(t, data[:, 1], color=colors[i], linewidth=1, label=leg)
    ax.set_title("Femur Angles")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Angle (deg)")
    ax.legend(loc='best', fontsize=7, ncol=2); ax.grid(True, alpha=0.3)

    # ---- Panel 6: Tibia Angles ----
    ax = axes[1, 2]
    if leg_names:
        for i, leg in enumerate(leg_names):
            data = np.array(telemetry.joint_angles[leg])
            ax.plot(t, data[:, 2], color=colors[i], linewidth=1, label=leg)
    ax.set_title("Tibia Angles")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Angle (deg)")
    ax.legend(loc='best', fontsize=7, ncol=2); ax.grid(True, alpha=0.3)

    # ================================================================ #
    #  Row 2: Power & Energy
    # ================================================================ #

    # ---- Panel 7: Total Power vs Time ----
    ax = axes[2, 0]
    ax.plot(t, power_total, color='crimson', linewidth=1.2, label='Total Power')
    ax.fill_between(t, power_total, alpha=0.25, color='crimson')
    ax.set_title("Total Power Consumption")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Power (W)")
    ax.legend(loc='best'); ax.grid(True, alpha=0.3)
    # Print stats
    if len(power_total) > 0:
        avg_p = np.mean(power_total)
        max_p = np.max(power_total)
        ax.text(0.98, 0.95,
                f"Avg: {avg_p:.2f} W\nMax: {max_p:.2f} W",
                transform=ax.transAxes, fontsize=8, verticalalignment='top',
                horizontalalignment='right',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.8))

    # ---- Panel 8: Power by Joint Type ----
    ax = axes[2, 1]
    ax.plot(t, power_per_type['coxa'],  color='steelblue',  linewidth=1.2,
            label='Coxa')
    ax.plot(t, power_per_type['femur'], color='darkorange', linewidth=1.2,
            label='Femur')
    ax.plot(t, power_per_type['tibia'], color='mediumseagreen', linewidth=1.2,
            label='Tibia')
    ax.plot(t, power_total, color='crimson', linewidth=0.8, linestyle='--',
            alpha=0.6, label='Total')
    ax.set_title("Power by Joint Type")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Power (W)")
    ax.legend(loc='best'); ax.grid(True, alpha=0.3)

    # ---- Panel 9: Cumulative Energy vs Time ----
    ax = axes[2, 2]
    ax.plot(t, energy_total, color='darkblue', linewidth=1.5, label='Total Energy')
    ax.fill_between(t, energy_total, alpha=0.2, color='darkblue')
    ax.set_title("Cumulative Energy Consumed")
    ax.set_xlabel("Time (s)"); ax.set_ylabel("Energy (J)")
    ax.legend(loc='best'); ax.grid(True, alpha=0.3)
    # Print stats
    if len(energy_total) > 0:
        total_e = energy_total[-1]
        avg_p = total_e / t[-1] if t[-1] > 0 else 0
        ax.text(0.98, 0.95,
                f"Total: {total_e:.3f} J\n"
                f"Avg Power: {avg_p:.2f} W\n"
                f"Duration: {t[-1]:.1f} s",
                transform=ax.transAxes, fontsize=8, verticalalignment='top',
                horizontalalignment='right',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='lightyellow',
                          alpha=0.9))

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"  Dashboard saved to: {save_path}")
    plt.show(block=False)
    plt.pause(0.3)

    # ---- Print energy summary to console ----
    print(f"\n  ---- ENERGY SUMMARY ----")
    print(f"  Duration        : {t[-1]:.2f} s")
    print(f"  Total energy    : {energy_total[-1]:.4f} J")
    print(f"  Avg power       : {np.mean(power_total):.4f} W")
    print(f"  Peak power      : {np.max(power_total):.4f} W")
    print(f"  Avg coxa power  : {np.mean(power_per_type['coxa']):.4f} W")
    print(f"  Avg femur power : {np.mean(power_per_type['femur']):.4f} W")
    print(f"  Avg tibia power : {np.mean(power_per_type['tibia']):.4f} W")
    print(f"  ------------------------\n")
