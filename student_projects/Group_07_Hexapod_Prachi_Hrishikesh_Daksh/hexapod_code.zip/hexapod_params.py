"""
=========================================================
  HEXAPOD PARAMETERS
  Central configuration — edit these to match your robot
=========================================================
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List

@dataclass
class HexapodParams:
    # Body
    body_radius: float = 0.122       # [m] hexagonal body circumradius

    # Link lengths
    L1: float = 0.060                # [m] coxa  (hip segment)
    L2: float = 0.116                # [m] femur (upper leg)
    L3: float = 0.170                # [m] tibia (lower leg)

    # Leg mounting angles (degrees, CCW from +X axis)
    num_legs: int = 6
    leg_angles: List[float] = field(
        default_factory=lambda: list(np.arange(6) * 60.0)
    )

    # Standing pose geometry
    # These define WHERE the feet are placed (in hip frame);
    # IK solves the joint angles automatically.
    foot_reach: float  = 0.120       # [m] horizontal distance from hip to foot
    body_height: float = 0.150       # [m] body centre height above ground

    # Gait parameters
    step_height: float = 0.04        # [m] foot lift during swing
    step_length: float = 0.08        # [m] stride length

    # Standing joint angles (degrees) — IK convention (for matplotlib visualisation)
    t1_stand: float =   0.0          # coxa  — relative to mount direction
    t2_stand: float =  30.0          # femur — positive = up
    t3_stand: float = -80.0          # tibia — negative = down

    # IK joint limits (degrees)
    t1_min: float = -45.0;  t1_max: float =  45.0
    t2_min: float =-120.0;  t2_max: float =  90.0
    t3_min: float =-150.0;  t3_max: float =   0.0

    # Leg names for display
    leg_names: List[str] = field(
        default_factory=lambda: ['FR', 'MR', 'RR', 'FL', 'ML', 'RL']
    )


def get_params() -> HexapodParams:
    return HexapodParams()
