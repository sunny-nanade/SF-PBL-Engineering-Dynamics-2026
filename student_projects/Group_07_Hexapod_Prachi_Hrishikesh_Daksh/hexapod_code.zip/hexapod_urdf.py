"""
=========================================================
  HEXAPOD URDF GENERATOR
  Generates a valid URDF file at runtime from params.
  This is far more reliable than createMultiBody for
  complex multi-limb robots.

  Each leg: 3 revolute joints (coxa→femur→tibia)
  Leg order: FR(0°) MR(60°) RR(120°) FL(180°) ML(240°) RL(300°)
=========================================================
"""

import os
import numpy as np
from hexapod_params import HexapodParams


def _generate_hex_body_mesh(filepath: str, circumradius: float,
                             thickness: float, bevel: float = 0.004):
    """
    Write a hexagonal prism OBJ mesh file.

    The body is a flat hexagonal plate with a slight bevel on the
    upper edge, inspired by the Bittle / insect-style hexapod look.
    Two groups in the OBJ:
      'body'  — main hexagonal prism
      'rim'   — thin raised lip around the upper perimeter
    """
    R   = circumradius
    R2  = R + bevel
    z0  = -thickness / 2
    z1  =  thickness / 2
    z2  =  thickness / 2 + bevel
    n   = 6

    verts = []
    faces = []
    idx   = 1  # OBJ is 1-indexed

    # ---- Main hexagonal prism (body) ----
    bottom_ring = []
    top_ring    = []
    for i in range(n):
        a = np.radians(60 * i)
        verts.append((R * np.cos(a), R * np.sin(a), z0))
        bottom_ring.append(idx); idx += 1
        verts.append((R * np.cos(a), R * np.sin(a), z1))
        top_ring.append(idx); idx += 1

    # Top face (fan from centre)
    center_top = idx; idx += 1
    verts.append((0, 0, z1))
    for i in range(n):
        v1 = top_ring[i]
        v2 = top_ring[(i + 1) % n]
        faces.append((v1, v2, center_top))

    # Bottom face (reversed winding)
    center_bot = idx; idx += 1
    verts.append((0, 0, z0))
    for i in range(n):
        v1 = bottom_ring[(i + 1) % n]
        v2 = bottom_ring[i]
        faces.append((v1, v2, center_bot))

    # Side faces
    for i in range(n):
        b1 = bottom_ring[i]; b2 = bottom_ring[(i + 1) % n]
        t1 = top_ring[i];    t2 = top_ring[(i + 1) % n]
        faces.append((b1, t1, t2))
        faces.append((b1, t2, b2))

    # ---- Raised rim (bevel around the top edge) ----
    rim_bot_ring = []
    rim_top_ring = []
    for i in range(n):
        a = np.radians(60 * i)
        verts.append((R * np.cos(a), R * np.sin(a), z1))
        rim_bot_ring.append(idx); idx += 1
        verts.append((R2 * np.cos(a), R2 * np.sin(a), z2))
        rim_top_ring.append(idx); idx += 1

    # Rim top face (fan from centre)
    rim_center = idx; idx += 1
    verts.append((0, 0, z2))
    for i in range(n):
        v1 = rim_top_ring[i]
        v2 = rim_top_ring[(i + 1) % n]
        faces.append((v1, v2, rim_center))

    # Rim side faces
    for i in range(n):
        b1 = rim_bot_ring[i]; b2 = rim_bot_ring[(i + 1) % n]
        t1 = rim_top_ring[i]; t2 = rim_top_ring[(i + 1) % n]
        faces.append((b1, t1, t2))
        faces.append((b1, t2, b2))

    # ---- Write OBJ ----
    with open(filepath, 'w') as f:
        f.write("# Hexapod body — auto-generated hexagonal prism\n")
        f.write("# Bittle / insect-style flat body plate\n\n")
        f.write("o body\n")
        for v in verts:
            f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
        for fc in faces:
            f.write(f"f {fc[0]} {fc[1]} {fc[2]}\n")

    print(f"  Body mesh written to: {filepath}")
    return filepath


def generate_urdf(params: HexapodParams, filepath: str = None):
    if filepath is None:
        import tempfile
        filepath = os.path.join(tempfile.gettempdir(), "hexapod.urdf")
    """
    Write a complete URDF for the hexapod and return the filepath.

    Coordinate conventions (body frame):
      X = forward, Y = left, Z = up
      Coxa  joint axis: Z  (horizontal swing)
      Femur joint axis: perp-to-coxa in horizontal plane (positive = up)
      Tibia joint axis: same as femur (positive = inward / knee bend under body)

    Angle convention (URDF ↔ IK mapping):
      URDF_coxa  = IK_t1 − mount_angle   (relative to mount direction)
      URDF_femur = IK_t2                 (positive = above horizontal)
      URDF_tibia = −IK_t3                (positive = inward from femur direction)
    """
    R  = params.body_radius
    L1 = params.L1   # coxa
    L2 = params.L2   # femur
    L3 = params.L3   # tibia
    n  = params.num_legs
    phi = params.leg_angles   # mounting angles in degrees

    # Link visual/collision dimensions
    body_z = 0.020   # body plate thickness [m]
    seg_r  = 0.009   # capsule radius for leg segments

    def rgb(r, g, b, a=1.0):
        return f"{r} {g} {b} {a}"

    lines = []
    lines.append('<?xml version="1.0"?>')
    lines.append('<robot name="hexapod">')

    # ---- Helper: inertia block (thin rod approximation) ----
    def inertia_box(m, x, y, z):
        ixx = m/12*(y**2+z**2); iyy = m/12*(x**2+z**2); izz = m/12*(x**2+y**2)
        return (f'<inertial><mass value="{m}"/>'
                f'<inertia ixx="{ixx:.6f}" ixy="0" ixz="0" '
                f'iyy="{iyy:.6f}" iyz="0" izz="{izz:.6f}"/></inertial>')

    def inertia_capsule(m, r, l):
        ixx = m*(3*r**2+l**2)/12; izz = m*r**2/2
        return (f'<inertial><mass value="{m}"/>'
                f'<inertia ixx="{ixx:.6f}" ixy="0" ixz="0" '
                f'iyy="{ixx:.6f}" iyz="0" izz="{izz:.6f}"/></inertial>')

    # ================================================================
    #  BASE LINK (body) — hexagonal mesh, Bittle-style dark colour
    # ================================================================
    # Generate hexagonal body mesh next to the URDF
    urdf_dir   = os.path.dirname(os.path.abspath(filepath))
    mesh_path  = os.path.join(urdf_dir, 'hexapod_body.obj')
    _generate_hex_body_mesh(mesh_path, R, body_z, bevel=0.004)
    mesh_rel   = os.path.basename(mesh_path)   # PyBullet resolves relative to URDF

    # Inertia for a hexagonal plate (approximate as cylinder of same area)
    hex_area  = (3 * np.sqrt(3) / 2) * R**2
    body_mass = 0.8
    ixx = body_mass / 12 * (2 * R)**2 + body_mass * (body_z**2 / 12)
    izz = body_mass / 12 * (2 * R)**2 * 0.5
    inertia_body = (f'<inertial><mass value="{body_mass}"/>'
                    f'<inertia ixx="{ixx:.6f}" ixy="0" ixz="0" '
                    f'iyy="{ixx:.6f}" iyz="0" izz="{izz:.6f}"/></inertial>')

    lines.append(f'''
  <link name="base">
    {inertia_body}
    <visual>
      <geometry><mesh filename="{mesh_rel}" scale="1 1 1"/></geometry>
      <material name="body_dark"><color rgba="{rgb(0.15,0.15,0.18)}"/></material>
    </visual>
    <collision>
      <geometry><cylinder radius="{R}" length="{body_z}"/></geometry>
    </collision>
  </link>''')

    # ================================================================
    #  LEG LINKS & JOINTS
    # ================================================================
    for i in range(n):
        angle_deg = phi[i]
        angle_rad = np.radians(angle_deg)
        leg = params.leg_names[i]

        # Hip attachment point on body perimeter
        hx = R * np.cos(angle_rad)
        hy = R * np.sin(angle_rad)

        # Coxa direction unit vector (outward from body)
        cx = np.cos(angle_rad)
        cy = np.sin(angle_rad)

        # ---- COXA link ----
        coxa_name  = f"coxa_{leg}"
        coxa_joint = f"j_coxa_{leg}"

        # Coxa is a capsule extending outward from hip
        # Visual origin is at midpoint of coxa
        lines.append(f'''
  <link name="{coxa_name}">
    {inertia_capsule(0.03, seg_r, L1)}
    <visual>
      <origin xyz="{L1/2*cx:.4f} {L1/2*cy:.4f} 0" rpy="0 {np.pi/2:.4f} {angle_rad:.4f}"/>
      <geometry><cylinder radius="{seg_r}" length="{L1}"/></geometry>
      <material name="dark_joint"><color rgba="{rgb(0.25,0.25,0.28)}"/></material>
    </visual>
    <collision>
      <origin xyz="{L1/2*cx:.4f} {L1/2*cy:.4f} 0" rpy="0 {np.pi/2:.4f} {angle_rad:.4f}"/>
      <geometry><cylinder radius="{seg_r}" length="{L1}"/></geometry>
    </collision>
  </link>

  <joint name="{coxa_joint}" type="revolute">
    <parent link="base"/>
    <child  link="{coxa_name}"/>
    <origin xyz="{hx:.4f} {hy:.4f} 0"/>
    <axis xyz="0 0 1"/>
    <limit lower="-0.785" upper="0.785" effort="5" velocity="3"/>
    <dynamics damping="0.1" friction="0.05"/>
  </joint>''')

        # ---- FEMUR link ----
        femur_name  = f"femur_{leg}"
        femur_joint = f"j_femur_{leg}"

        # Femur origin is at end of coxa (tip)
        # Femur goes diagonally downward — axis is Y (perpendicular to coxa direction)
        # Visual: cylinder along coxa direction, origin at femur midpoint
        lines.append(f'''
  <link name="{femur_name}">
    {inertia_capsule(0.04, seg_r, L2)}
    <visual>
      <origin xyz="{L2/2*cx:.4f} {L2/2*cy:.4f} 0" rpy="0 {np.pi/2:.4f} {angle_rad:.4f}"/>
      <geometry><cylinder radius="{seg_r}" length="{L2}"/></geometry>
      <material name="femur_dark"><color rgba="{rgb(0.12,0.12,0.14)}"/></material>
    </visual>
    <collision>
      <origin xyz="{L2/2*cx:.4f} {L2/2*cy:.4f} 0" rpy="0 {np.pi/2:.4f} {angle_rad:.4f}"/>
      <geometry><cylinder radius="{seg_r}" length="{L2}"/></geometry>
    </collision>
  </link>

  <joint name="{femur_joint}" type="revolute">
    <parent link="{coxa_name}"/>
    <child  link="{femur_name}"/>
    <origin xyz="{L1*cx:.4f} {L1*cy:.4f} 0"/>
    <axis xyz="{-cy:.4f} {cx:.4f} 0"/>
    <limit lower="-1.571" upper="1.571" effort="5" velocity="3"/>
    <dynamics damping="0.1" friction="0.05"/>
  </joint>''')

        # ---- TIBIA link ----
        tibia_name  = f"tibia_{leg}"
        tibia_joint = f"j_tibia_{leg}"

        lines.append(f'''
  <link name="{tibia_name}">
    {inertia_capsule(0.03, seg_r, L3)}
    <visual>
      <origin xyz="{L3/2*cx:.4f} {L3/2*cy:.4f} 0" rpy="0 {np.pi/2:.4f} {angle_rad:.4f}"/>
      <geometry><cylinder radius="{seg_r}" length="{L3}"/></geometry>
      <material name="tibia_grey"><color rgba="{rgb(0.35,0.35,0.38)}"/></material>
    </visual>
    <collision>
      <origin xyz="{L3/2*cx:.4f} {L3/2*cy:.4f} 0" rpy="0 {np.pi/2:.4f} {angle_rad:.4f}"/>
      <geometry><cylinder radius="{seg_r*0.7}" length="{L3}"/></geometry>
    </collision>
  </link>

  <joint name="{tibia_joint}" type="revolute">
    <parent link="{femur_name}"/>
    <child  link="{tibia_name}"/>
    <origin xyz="{L2*cx:.4f} {L2*cy:.4f} 0"/>
    <axis xyz="{-cy:.4f} {cx:.4f} 0"/>
    <limit lower="-0.3" upper="2.618" effort="5" velocity="3"/>
    <dynamics damping="0.1" friction="0.05"/>
  </joint>''')

        # ---- FOOT (small sphere for contact) ----
        foot_name  = f"foot_{leg}"
        foot_joint = f"j_foot_{leg}"

        lines.append(f'''
  <link name="{foot_name}">
    <inertial><mass value="0.005"/>
      <inertia ixx="1e-6" ixy="0" ixz="0" iyy="1e-6" iyz="0" izz="1e-6"/>
    </inertial>
    <visual>
      <geometry><sphere radius="0.012"/></geometry>
      <material name="black"><color rgba="{rgb(0.1,0.1,0.1)}"/></material>
    </visual>
    <collision>
      <geometry><sphere radius="0.012"/></geometry>
    </collision>
  </link>

  <joint name="{foot_joint}" type="fixed">
    <parent link="{tibia_name}"/>
    <child  link="{foot_name}"/>
    <origin xyz="{L3*cx:.4f} {L3*cy:.4f} 0"/>
  </joint>''')

    lines.append('</robot>')

    urdf_str = '\n'.join(lines)
    with open(filepath, 'w') as f:
        f.write(urdf_str)

    print(f"  URDF written to: {filepath}")
    return filepath


def get_joint_map(p, robot_id, params):
    """
    Returns dict mapping (leg_name, joint_type) -> joint_index.
    E.g. ('FR', 'coxa') -> 0
    """
    joint_map = {}
    num_joints = p.getNumJoints(robot_id)
    for j in range(num_joints):
        info = p.getJointInfo(robot_id, j)
        jname = info[1].decode()   # e.g. "j_coxa_FR"
        if jname.startswith('j_') and '_' in jname[2:]:
            parts = jname.split('_')
            # parts: ['j', 'coxa', 'FR'] or ['j', 'femur', 'FR'] etc.
            if len(parts) == 3:
                jtype = parts[1]   # coxa / femur / tibia
                leg   = parts[2]   # FR / MR etc.
                joint_map[(leg, jtype)] = j
    return joint_map
