"""

=========================================================
  KEYBOARD CONTROLLER — STANDALONE LAUNCHER
  Run:  python hexapod_keyboard_controller.py

  Keys:
    D / A   →  crab right / left  (lateral)
    W / S   →  forward / backward
    E       →  turn right
    Q       →  turn left  (also exits if tapped twice)
    ESC     →  quit
=========================================================
"""

from hexapod_params  import get_params
from hexapod_visualize import HexapodKeyboardController


def main():
    print("===========================================")
    print("   HEXAPOD KEYBOARD CONTROLLER — PYBULLET ")
    print("===========================================")
    try:
        import pybullet  # noqa
    except ImportError:
        print("ERROR: pip install pybullet")
        return

    params     = get_params()
    controller = HexapodKeyboardController(params)
    controller.run_interactive()


if __name__ == "__main__":
    main()
