"""
=========================================================
  MODULE 1: FORWARD KINEMATICS
  Computes foot position from joint angles using
  Denavit-Hartenberg (DH) transformations.

  Conversion of hexapod_forward_kinematics.m
=========================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from hexapod_params import HexapodParams


# ------------------------------------------------------------------ #
#  DH Transformation matrix (MATLAB equivalent)
#  Each joint: rotate by theta, translate by link length a
#  alpha = 0 (planar leg), d = 0
# ------------------------------------------------------------------ #
def dh_transform(theta_deg: float, a: float) -> np.ndarray:
    """
    Returns a 4x4 homogeneous DH transform for a single revolute joint.
      theta : joint angle [degrees]
      a     : link length along x [m]
    """
    t = np.radians(theta_deg)
    c, s = np.cos(t), np.sin(t)
    return np.array([
        [c, -s, 0, a * c],
        [s,  c, 0, a * s],
        [0,  0, 1, 0    ],
        [0,  0, 0, 1    ]
    ])


def forward_kinematics(theta1: float, theta2: float, theta3: float,
                       L1: float, L2: float, L3: float) -> np.ndarray:
    """
    Full FK chain: T = T01 * T12 * T23
    Returns foot position [x, y, z] as (3,) array.
    """
    T = dh_transform(theta1, L1) @ dh_transform(theta2, L2) @ dh_transform(theta3, L3)
    return T[:3, 3]


def run_forward_kinematics(params: HexapodParams):
    L1, L2, L3 = params.L1, params.L2, params.L3

    print("\n--- FORWARD KINEMATICS ---")
    print(f"Link lengths: L1={L1:.3f}m, L2={L2:.3f}m, L3={L3:.3f}m\n")

    # Same test cases as MATLAB
    test_cases = [
        (  0,  30, -60),   # standing pose
        ( 30,  45, -90),   # mid-swing
        (-15,  20, -45),   # lean forward
    ]

    header = f"{'theta1':>8} {'theta2':>8} {'theta3':>8} | {'X(m)':>8} {'Y(m)':>8} {'Z(m)':>8}"
    print(header)
    print("-" * 52)

    for t1, t2, t3 in test_cases:
        foot = forward_kinematics(t1, t2, t3, L1, L2, L3)
        print(f"{t1:>8.1f} {t2:>8.1f} {t3:>8.1f} | "
              f"{foot[0]:>8.4f} {foot[1]:>8.4f} {foot[2]:>8.4f}")

    # ---- Plot workspace (sweep all joint angle combinations) ----
    pts = []
    for t1 in range(-45, 46, 15):
        for t2 in range(0, 91, 15):
            for t3 in range(-150, 1, 15):
                p = forward_kinematics(t1, t2, t3, L1, L2, L3)
                pts.append(p)
    pts = np.array(pts)

    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    sc = ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2],
                    c=pts[:, 2], cmap='jet', s=2)
    plt.colorbar(sc, ax=ax, label='Z (m)')
    ax.set_title("Single Leg Workspace (FK sweep)")
    ax.set_xlabel("X (m)"); ax.set_ylabel("Y (m)"); ax.set_zlabel("Z (m)")
    ax.view_init(elev=30, azim=45)
    plt.tight_layout()
    print("  -> Workspace plot ready.")
