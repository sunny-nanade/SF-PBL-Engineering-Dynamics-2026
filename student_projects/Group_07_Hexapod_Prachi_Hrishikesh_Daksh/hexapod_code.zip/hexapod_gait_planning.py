"""
=========================================================
  MODULE 3: GAIT PLANNING
  Models tripod, ripple, and wave gaits using phase
  relationships. Plots foot trajectories over time.

  Conversion of hexapod_gait_planning.m
=========================================================
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from dataclasses import dataclass
from typing import List
from hexapod_params import HexapodParams


@dataclass
class Gait:
    name: str
    offsets: List[float]   # phase offset per leg [0–1]
    beta: float            # duty factor (fraction of cycle in stance)


# ---- Gait definitions (FR, MR, RR, FL, ML, RL) ----
GAITS = [
    Gait("Tripod", [0, 0.5, 0, 0.5, 0, 0.5], 0.5),
    Gait("Ripple", [0, 1/3, 2/3, 0.5, 5/6, 1/6], 2/3),
    Gait("Wave",   [0, 1/6, 2/6, 3/6, 4/6, 5/6], 5/6),
]

LEG_NAMES = ['FR', 'MR', 'RR', 'FL', 'ML', 'RL']


def swing_z(swing_phase: float, h: float) -> float:
    """Sinusoidal foot lift during swing (swing_phase 0→1)."""
    return h * max(0.0, np.sin(np.pi * swing_phase))


def swing_x(swing_phase: float, sl: float) -> float:
    """Linear foot travel from -sl/2 (back) to +sl/2 (front)."""
    return sl * (swing_phase - 0.5)


def contact_schedule(t: float, T_cycle: float,
                     offset: float, beta: float) -> int:
    """Returns 1 (stance) or 0 (swing) for a leg at time t."""
    phase = (t / T_cycle + offset) % 1.0
    return 1 if phase < beta else 0


def run_gait_planning(params: HexapodParams):
    n  = params.num_legs
    h  = params.step_height
    sl = params.step_length

    T_cycle = 2.0         # [s] gait cycle period
    dt      = 0.01        # [s] time step
    t       = np.arange(0, 2 * T_cycle + dt, dt)

    colors = plt.cm.tab10(np.linspace(0, 1, n))

    fig, axes = plt.subplots(3, 3, figsize=(14, 9))
    fig.suptitle("Hexapod Gait Comparison: Tripod | Ripple | Wave",
                 fontsize=14, fontweight='bold')

    print("\n--- GAIT PLANNING ---")

    for g_idx, gait in enumerate(GAITS):
        offsets = gait.offsets
        beta    = gait.beta

        # ---- Column 0: Phase bar chart ----
        ax_bar = axes[g_idx, 0]
        ax_bar.set_title(f"{gait.name} Gait — Phase Bars")
        ax_bar.set_xlabel("Phase (0 to 1)")
        ax_bar.set_ylabel("Leg")
        ax_bar.set_xlim(0, 1); ax_bar.set_ylim(0, n + 1)
        ax_bar.set_yticks(range(1, n + 1)); ax_bar.set_yticklabels(LEG_NAMES)

        for i in range(n):
            off         = offsets[i]
            swing_start = (off + beta) % 1.0
            swing_dur   = 1.0 - beta
            # Stance (blue)
            ax_bar.broken_barh([(0, beta)], (i + 0.6, 0.8),
                               facecolors=(0.2, 0.5, 1.0, 0.6))
            # Swing (red)
            ax_bar.broken_barh([(swing_start, swing_dur)], (i + 0.6, 0.8),
                               facecolors=(1.0, 0.3, 0.3, 0.8))
            ax_bar.text(0.02, i + 1, f"{beta*100:.0f}%",
                        fontsize=7, color='white', fontweight='bold')

        stance_patch = mpatches.Patch(color=(0.2, 0.5, 1, 0.6), label='Stance')
        swing_patch  = mpatches.Patch(color=(1.0, 0.3, 0.3, 0.8), label='Swing')
        ax_bar.legend(handles=[stance_patch, swing_patch],
                      loc='lower right', fontsize=7)

        # ---- Column 1: Foot Z-height vs time ----
        ax_z = axes[g_idx, 1]
        ax_z.set_title(f"{gait.name} — Foot Height vs Time")
        ax_z.set_xlabel("Time (s)"); ax_z.set_ylabel("Z height (m)")
        ax_z.grid(True)

        for i in range(n):
            z_traj = np.zeros(len(t))
            for k, tk in enumerate(t):
                phase_raw = (tk / T_cycle + offsets[i]) % 1.0
                if phase_raw >= beta:
                    sp = (phase_raw - beta) / (1.0 - beta)
                    z_traj[k] = swing_z(sp, h)
            ax_z.plot(t, z_traj, color=colors[i], linewidth=1.5,
                      label=LEG_NAMES[i])
        ax_z.legend(loc='upper right', fontsize=7)

        # ---- Column 2: Foot X-position vs time ----
        ax_x = axes[g_idx, 2]
        ax_x.set_title(f"{gait.name} — Foot X vs Time")
        ax_x.set_xlabel("Time (s)"); ax_x.set_ylabel("X position (m)")
        ax_x.grid(True)

        for i in range(n):
            x_traj = np.zeros(len(t))
            for k, tk in enumerate(t):
                phase_raw = (tk / T_cycle + offsets[i]) % 1.0
                if phase_raw >= beta:
                    sp = (phase_raw - beta) / (1.0 - beta)
                    x_traj[k] = swing_x(sp, sl)
                else:
                    sp = phase_raw / beta
                    x_traj[k] = sl / 2 - sl * sp
            ax_x.plot(t, x_traj, color=colors[i], linewidth=1.5,
                      label=LEG_NAMES[i])
        ax_x.legend(loc='upper right', fontsize=7)

    plt.tight_layout()
    print(f"  Duty factors -> Tripod: 50%, Ripple: 67%, Wave: 83%")
    print("  -> Gait plots ready.")
