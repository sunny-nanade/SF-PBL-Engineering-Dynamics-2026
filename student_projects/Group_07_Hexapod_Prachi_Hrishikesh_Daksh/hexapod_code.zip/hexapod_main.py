"""
=========================================================
  HEXAPOD ROBOT - MAIN SCRIPT
  Python conversion of MATLAB hexapod model
  Uses PyBullet for physics simulation & 3D visualization

  Run:  python hexapod_main.py
  Deps: pip install pybullet numpy matplotlib scipy
=========================================================
"""

import matplotlib
matplotlib.use('TkAgg')   # non-blocking backend; fallback to Qt5Agg if needed
import matplotlib.pyplot as plt

from hexapod_params             import get_params
from hexapod_forward_kinematics import run_forward_kinematics
from hexapod_inverse_kinematics import run_inverse_kinematics
from hexapod_gait_planning      import run_gait_planning
from hexapod_stability          import run_stability_analysis
from hexapod_visualize          import run_visualization


def main():
    print("===========================================")
    print("   HEXAPOD MATHEMATICAL MODEL - PYTHON    ")
    print("===========================================\n")

    params = get_params()

    # ---- MODULE 1: Forward Kinematics ----
    print("[1] Running Forward Kinematics...")
    run_forward_kinematics(params)
    plt.show(block=False); plt.pause(0.3)

    # ---- MODULE 2: Inverse Kinematics ----
    print("\n[2] Running Inverse Kinematics...")
    run_inverse_kinematics(params)
    plt.show(block=False); plt.pause(0.3)

    # ---- MODULE 3: Gait Planning ----
    print("\n[3] Running Gait Planning...")
    run_gait_planning(params)
    plt.show(block=False); plt.pause(0.3)

    # ---- MODULE 4: Stability Analysis ----
    print("\n[4] Running Stability Analysis...")
    run_stability_analysis(params)
    plt.show(block=False); plt.pause(0.3)

    # ---- MODULE 5: PyBullet Simulation ----
    # This blocks until the PyBullet window is closed or ESC/Q is pressed.
    # All matplotlib windows remain visible in the background.
    print("\n[5] Launching PyBullet Simulation...")
    print("    Matplotlib plots remain open in the background.")
    print("    Close the PyBullet window or press ESC/Q inside it to exit.\n")
    run_visualization(params)

    # After PyBullet exits, keep matplotlib windows open
    print("\nAll modules complete. Close plot windows to exit.")
    plt.show(block=True)


if __name__ == "__main__":
    main()
