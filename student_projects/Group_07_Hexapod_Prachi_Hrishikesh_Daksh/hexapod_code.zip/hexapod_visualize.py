"""
=========================================================
  MODULE 4+5: 3D VISUALIZATION & PYBULLET SIMULATION

  CONTROLS (both input methods supported):
    W / Arrow UP     = forward
    S / Arrow DOWN   = backward
    A / Arrow LEFT   = crab left
    D / Arrow RIGHT  = crab right
    Q / NUMPAD 4     = turn left
    E / NUMPAD 6     = turn right
    SPACE            = stop / stand
    ESC              = quit

  PyBullet keyboard shortcuts are disabled so WASD
  does NOT conflict with the camera.

  Angle convention (critical):
    IK solver returns (t1, t2, t3) where:
      t1 = absolute horizontal angle from +X axis
      t2 = femur angle from horizontal (positive = up)
      t3 = tibia angle relative to femur (negative = knee down)

    URDF joints expect:
      coxa  = t1 - mount_angle  (relative to mount direction)
      femur = t2                (same convention: positive = up)
      tibia = -t3               (positive = inward from femur direction)
=========================================================
"""

import os
import time
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from hexapod_params import HexapodParams
from hexapod_inverse_kinematics import solve_ik, reconstruct_leg_points
from hexapod_analytics import Telemetry, plot_dashboard


# ================================================================== #
#  MATPLOTLIB STATIC VISUALIZATION
# ================================================================== #

def leg_points_3d(mount_deg, t1_rel, t2, t3, R, L1, L2, L3):
    """
    Compute 3D joint positions for a single leg.

    Parameters
    ----------
    mount_deg : float — leg mount angle in degrees
    t1_rel    : float — coxa angle RELATIVE to mount direction (degrees)
    t2        : float — femur angle from horizontal (degrees, IK convention)
    t3        : float — tibia angle relative to femur (degrees, IK convention)
    """
    a   = np.radians(mount_deg)
    hip = np.array([R * np.cos(a), R * np.sin(a), 0.0])
    # Absolute direction of the leg
    d = np.radians(mount_deg + t1_rel)
    J1 = hip + np.array([L1 * np.cos(d), L1 * np.sin(d), 0.0])
    J2 = J1  + np.array([L2 * np.cos(d) * np.cos(np.radians(t2)),
                          L2 * np.sin(d) * np.cos(np.radians(t2)),
                          L2 * np.sin(np.radians(t2))])
    J3 = J2  + np.array([L3 * np.cos(d) * np.cos(np.radians(t2 + t3)),
                          L3 * np.sin(d) * np.cos(np.radians(t2 + t3)),
                          L3 * np.sin(np.radians(t2 + t3))])
    return np.array([hip, J1, J2, J3])


def plot_static_pose(params: HexapodParams, ax):
    """Plot the hexapod standing pose using IK-computed angles."""
    R, L1, L2, L3 = params.body_radius, params.L1, params.L2, params.L3
    phi    = np.array(params.leg_angles)
    colors = plt.cm.tab10(np.linspace(0, 1, params.num_legs))

    # Draw hexagonal body
    bx = np.append(R * np.cos(np.radians(phi)), R * np.cos(np.radians(phi[0])))
    by = np.append(R * np.sin(np.radians(phi)), R * np.sin(np.radians(phi[0])))
    ax.plot(bx, by, np.zeros(len(bx)), 'b-', lw=2)
    verts = [list(zip(R * np.cos(np.radians(phi)),
                      R * np.sin(np.radians(phi)),
                      np.zeros(params.num_legs)))]
    ax.add_collection3d(Poly3DCollection(verts, alpha=0.4, facecolor='steelblue'))

    for i in range(params.num_legs):
        mount = phi[i]
        a_rad = np.radians(mount)
        cx, cy = np.cos(a_rad), np.sin(a_rad)

        # Foot position in hip frame (directly outward, at params.foot_reach)
        px = params.foot_reach * cx
        py = params.foot_reach * cy
        pz = -params.body_height

        # Solve IK
        t1_abs, t2, t3, valid = solve_ik(px, py, pz, L1, L2, L3)
        t1_rel = t1_abs - mount  # relative to mount direction

        if not valid:
            print(f"  WARNING: Leg {params.leg_names[i]} standing pose IK failed!")

        pts = leg_points_3d(mount, t1_rel, t2, t3, R, L1, L2, L3)
        ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], '-o',
                color=colors[i], lw=2, ms=5)
        ax.text(pts[-1, 0], pts[-1, 1], pts[-1, 2] - 0.015,
                params.leg_names[i], fontsize=8,
                color=colors[i], fontweight='bold')

    ax.set(xlabel='X(m)', ylabel='Y(m)', zlabel='Z(m)',
           xlim=(-0.35, 0.35), ylim=(-0.35, 0.35), zlim=(-0.25, 0.15),
           title='Hexapod Standing Pose (IK-computed)')
    ax.view_init(elev=25, azim=40)


# ================================================================== #
#  KEY CONSTANTS
#  Arrow keys AND W/A/S/D/E/Q are both supported.
#  PyBullet keyboard shortcuts are already disabled in __init__,
#  so WASD will not conflict with the camera.
# ================================================================== #
KEY_UP    = 65297   # Arrow Up    -> forward
KEY_DOWN  = 65298   # Arrow Down  -> backward
KEY_LEFT  = 65295   # Arrow Left  -> crab left
KEY_RIGHT = 65296   # Arrow Right -> crab right
KEY_NUM4  = 65460   # Numpad 4    -> turn left
KEY_NUM6  = 65462   # Numpad 6    -> turn right
KEY_SPACE = 32      # Space       -> stop
KEY_ESC   = 27      # ESC         -> quit

# W/A/S/D and Q/E — ASCII codes for both upper and lower case
KEY_W = 87;  KEY_w = 119   # W / w -> forward
KEY_S = 83;  KEY_s = 115   # S / s -> backward
KEY_A = 65;  KEY_a = 97    # A / a -> crab left
KEY_D = 68;  KEY_d = 100   # D / d -> crab right
KEY_Q = 81;  KEY_q = 113   # Q / q -> turn left
KEY_E = 69;  KEY_e = 101   # E / e -> turn right


# ================================================================== #
#  PYBULLET SIMULATION
# ================================================================== #

class HexapodSim:
    """
    PyBullet hexapod loaded from a runtime-generated URDF.

    IK-to-URDF angle mapping (verified):
      urdf_coxa  = ik_t1 - mount_angle   (relative to mount direction)
      urdf_femur = ik_t2                 (positive = above horizontal)
      urdf_tibia = -ik_t3                (positive = inward under body)
    """

    # Tripod phase offsets per leg
    # Group A (phase=0.0): FR, RR, ML
    # Group B (phase=0.5): MR, FL, RL
    TRIPOD_PHASE = {
        'FR': 0.0, 'RR': 0.0, 'ML': 0.0,
        'MR': 0.5, 'FL': 0.5, 'RL': 0.5,
    }
    BETA = 0.5   # duty factor

    def __init__(self, params: HexapodParams, gui: bool = True):
        import pybullet as p
        import pybullet_data
        from hexapod_urdf import generate_urdf, get_joint_map

        self.p      = p
        self.params = params

        # ---- Connect ----
        p.connect(p.GUI if gui else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.setGravity(0, 0, -9.81)
        p.setTimeStep(1.0 / 240.0)
        p.setRealTimeSimulation(0)   # manual timing

        # ---- Disable built-in keyboard/mouse camera so arrow keys work ----
        p.configureDebugVisualizer(p.COV_ENABLE_KEYBOARD_SHORTCUTS, 0)
        p.configureDebugVisualizer(p.COV_ENABLE_MOUSE_PICKING, 0)

        # ---- Ground ----
        p.loadURDF("plane.urdf")

        # ---- Camera ----
        p.resetDebugVisualizerCamera(
            cameraDistance=0.6,
            cameraYaw=45,
            cameraPitch=-30,
            cameraTargetPosition=[0, 0, 0.05]
        )

        # ---- Compute standing pose & spawn height ----
        self.stand_angs = self._compute_stand_angles()
        self.spawn_h    = self._calc_spawn_height()

        # ---- Load URDF ----
        urdf_path  = generate_urdf(params)
        self.robot = p.loadURDF(
            urdf_path,
            basePosition=[0, 0, self.spawn_h],
            baseOrientation=p.getQuaternionFromEuler([0, 0, 0]),
            flags=p.URDF_USE_INERTIA_FROM_FILE
        )
        print(f"  Robot loaded — spawn h={self.spawn_h:.3f}m, "
              f"joints={p.getNumJoints(self.robot)}")

        # ---- Joint map ----
        self.joint_map = get_joint_map(p, self.robot, params)
        self._enable_motors()

        # ---- HARD RESET TO STANDING POSE ----
        for leg, (c, f, t) in self.stand_angs.items():
            for jt, ang in [('coxa', c), ('femur', f), ('tibia', t)]:
                idx = self.joint_map.get((leg, jt))
                if idx is not None:
                    self.p.resetJointState(self.robot, idx, ang)

        # ---- HUD ----
        self.hud_id = p.addUserDebugText(
            "Hexapod | Initialising...",
            [0, 0, self.spawn_h + 0.20],
            textColorRGB=[0.2, 1.0, 0.2],
            textSize=1.4
        )

        # Print controls to terminal
        print("\n  +-------------------------------------------+")
        print("  |           HEXAPOD CONTROLS               |")
        print("  |   W / Arrow UP    = forward              |")
        print("  |   S / Arrow DOWN  = backward             |")
        print("  |   A / Arrow LEFT  = crab left            |")
        print("  |   D / Arrow RIGHT = crab right           |")
        print("  |   Q / Numpad 4    = turn left            |")
        print("  |   E / Numpad 6    = turn right           |")
        print("  |   SPACE           = stop / stand         |")
        print("  |   ESC             = quit                 |")
        print("  +-------------------------------------------+\n")

    # ---------------------------------------------------------------- #
    def _compute_stand_angles(self) -> dict:
        """
        Compute URDF standing angles per leg using IK.

        For each leg:
          1. Place foot at (foot_reach * cos(mount), foot_reach * sin(mount), -body_height)
             relative to the hip (in hip frame).
          2. Solve IK for (t1, t2, t3).
          3. Convert to URDF angles: coxa=t1-mount, femur=t2, tibia=-t3.
        """
        p = self.params
        R, L1, L2, L3 = p.body_radius, p.L1, p.L2, p.L3
        out = {}

        for i, leg in enumerate(p.leg_names):
            mount_deg = p.leg_angles[i]
            mount_rad = np.radians(mount_deg)
            cx, cy = np.cos(mount_rad), np.sin(mount_rad)

            # Desired foot position in hip frame
            px = p.foot_reach * cx
            py = p.foot_reach * cy
            pz = -p.body_height

            t1, t2, t3, valid = solve_ik(px, py, pz, L1, L2, L3)

            if not valid:
                print(f"  WARNING: IK failed for leg {leg}! "
                      f"foot=({px:.3f},{py:.3f},{pz:.3f})")
                # Fallback: use simple geometric estimate
                r = np.sqrt(px**2 + py**2) - L1
                D = np.sqrt(r**2 + pz**2)
                cos_t3 = np.clip((D**2 - L2**2 - L3**2) / (2*L2*L3), -1, 1)
                t3 = -np.degrees(np.arccos(cos_t3))
                alpha = np.degrees(np.arctan2(pz, r))
                beta  = np.degrees(np.arctan2(
                    L3 * np.sin(np.radians(-t3)),
                    L2 + L3 * np.cos(np.radians(-t3))))
                t2 = alpha + beta
                t1 = np.degrees(np.arctan2(py, px))

            # Convert IK angles to URDF angles
            coxa_deg = (t1 - mount_deg + 180) % 360 - 180  # normalise to [-180, 180]
            urdf_coxa  = np.radians(coxa_deg)               # relative to mount direction
            urdf_femur = np.radians(t2)                     # positive = up
            urdf_tibia = -np.radians(t3)                    # positive = inward

            out[leg] = (urdf_coxa, urdf_femur, urdf_tibia)

            # Debug print
            print(f"  {leg}: mount={mount_deg:5.1f}  IK=({t1:7.2f}, {t2:7.2f}, {t3:7.2f})"
                  f"  URDF=({coxa_deg:7.2f}, {np.degrees(urdf_femur):7.2f}, "
                  f"{np.degrees(urdf_tibia):7.2f})")

        return out

    # ---------------------------------------------------------------- #
    def _calc_spawn_height(self) -> float:
        """
        Compute body spawn height so feet just touch the ground.

        At standing pose, the foot is at -body_height relative to the hip.
        The hip is on the body at z=0. So foot is at -body_height in body frame.
        We spawn the body at body_height above the ground plane (z=0).
        """
        return self.params.body_height + 0.005   # small clearance to avoid sinking

    # ---------------------------------------------------------------- #
    def _enable_motors(self):
        p = self.p
        for j in range(p.getNumJoints(self.robot)):
            if p.getJointInfo(self.robot, j)[2] == p.JOINT_REVOLUTE:
                p.setJointMotorControl2(
                    self.robot, j,
                    controlMode=p.POSITION_CONTROL,
                    targetPosition=0.0,
                    force=10.0, maxVelocity=10.0
                )

    # ---------------------------------------------------------------- #
    def _set_leg(self, leg: str, coxa: float, femur: float, tibia: float):
        p = self.p
        for jt, ang in [('coxa', coxa), ('femur', femur), ('tibia', tibia)]:
            idx = self.joint_map.get((leg, jt))
            if idx is not None:
                p.setJointMotorControl2(
                    self.robot, idx,
                    controlMode=p.POSITION_CONTROL,
                    targetPosition=float(ang),
                    force=6.0, maxVelocity=6.0
                )

    # ---------------------------------------------------------------- #
    def stand(self):
        """Drive all legs to the computed standing pose."""
        for leg, (c, f, t) in self.stand_angs.items():
            self._set_leg(leg, c, f, t)

    # ---------------------------------------------------------------- #
    def _gait_step(self, t: float, T: float, direction: str):
        """
        IK-based tripod gait.

        Instead of blindly sweeping the coxa (which cancels to zero net
        force on a symmetric hexapod), this method computes the *desired
        foot position* in Cartesian space and uses the IK solver to find
        the correct joint angles for every leg at every timestep.

        During stance the foot slides backward (opposite to travel
        direction), pushing the body forward.  During swing the foot
        lifts and repositions for the next stance phase.

        Parameters
        ----------
        t         : current time
        T         : gait cycle period
        direction : 'forward' | 'backward' | 'crab_left' |
                    'crab_right' | 'turn_left' | 'turn_right'
        """
        params = self.params
        L1, L2, L3 = params.L1, params.L2, params.L3
        stride = params.step_length   # 0.06 m total stride
        height = params.step_height   # 0.04 m foot lift

        # Desired travel direction in the body frame (X = fwd, Y = left)
        dir_vectors = {
            'forward':    np.array([ 1.0,  0.0]),
            'backward':   np.array([-1.0,  0.0]),
            'crab_left':  np.array([ 0.0,  1.0]),
            'crab_right': np.array([ 0.0, -1.0]),
        }

        for i, leg in enumerate(params.leg_names):
            mount_deg = params.leg_angles[i]
            mount_rad = np.radians(mount_deg)
            cx, cy = np.cos(mount_rad), np.sin(mount_rad)

            phase_offset = self.TRIPOD_PHASE[leg]
            phase = (t / T + phase_offset) % 1.0

            # --- Standing foot position (hip frame) ---
            stand_x = params.foot_reach * cx
            stand_y = params.foot_reach * cy
            stand_z = -params.body_height

            if direction in dir_vectors:
                # ---- Translational gait ----
                d = dir_vectors[direction]
                if phase < self.BETA:
                    # Stance: foot slides opposite to travel direction
                    stance_frac = phase / self.BETA
                    offset = stride * (0.5 - stance_frac)
                    foot_x = stand_x + d[0] * offset
                    foot_y = stand_y + d[1] * offset
                    foot_z = stand_z
                else:
                    # Swing: foot lifts and repositions forward
                    swing_frac = (phase - self.BETA) / (1.0 - self.BETA)
                    offset = stride * (-0.5 + swing_frac)
                    lift = height * np.sin(np.pi * swing_frac)
                    foot_x = stand_x + d[0] * offset
                    foot_y = stand_y + d[1] * offset
                    foot_z = stand_z + lift

            elif direction in ('turn_left', 'turn_right'):
                # ---- Turning gait ----
                # Tangent direction at the foot's radial position.
                # CW  for turn_right: ( cy, -cx)
                # CCW for turn_left:  (-cy,  cx)
                if direction == 'turn_right':
                    tang = np.array([ cy, -cx])
                else:
                    tang = np.array([-cy,  cx])

                if phase < self.BETA:
                    stance_frac = phase / self.BETA
                    offset = stride * (0.5 - stance_frac)
                    foot_x = stand_x + tang[0] * offset
                    foot_y = stand_y + tang[1] * offset
                    foot_z = stand_z
                else:
                    swing_frac = (phase - self.BETA) / (1.0 - self.BETA)
                    offset = stride * (-0.5 + swing_frac)
                    lift = height * np.sin(np.pi * swing_frac)
                    foot_x = stand_x + tang[0] * offset
                    foot_y = stand_y + tang[1] * offset
                    foot_z = stand_z + lift
            else:
                continue

            # --- Solve IK for the desired foot position ---
            t1, t2, t3, valid = solve_ik(foot_x, foot_y, foot_z,
                                         L1, L2, L3)
            if not valid:
                # Foot unreachable — hold standing pose for this leg
                c0, f0, t0 = self.stand_angs[leg]
                self._set_leg(leg, c0, f0, t0)
                continue

            # Convert IK angles → URDF angles
            coxa_deg = (t1 - mount_deg + 180) % 360 - 180
            urdf_coxa  = np.radians(coxa_deg)
            urdf_femur = np.radians(t2)
            urdf_tibia = -np.radians(t3)

            self._set_leg(leg, urdf_coxa, urdf_femur, urdf_tibia)

    # ---------------------------------------------------------------- #
    def _read_keys(self):
        """
        Poll PyBullet keyboard.  Returns (direction, quit).
        Accepts both Arrow keys / Numpad AND W/A/S/D/Q/E.
        """
        try:
            keys = self.p.getKeyboardEvents()
        except Exception:
            return 'idle', True

        IS_DOWN = self.p.KEY_IS_DOWN

        def pressed(*codes):
            return any(c in keys and keys[c] & IS_DOWN for c in codes)

        if pressed(KEY_ESC):
            return 'idle', True

        if pressed(KEY_UP, KEY_w, KEY_W):
            return 'forward',    False
        if pressed(KEY_DOWN, KEY_s, KEY_S):
            return 'backward',   False
        if pressed(KEY_LEFT, KEY_a, KEY_A):
            return 'crab_left',  False
        if pressed(KEY_RIGHT, KEY_d, KEY_D):
            return 'crab_right', False
        if pressed(KEY_NUM4, KEY_q, KEY_Q):
            return 'turn_left',  False
        if pressed(KEY_NUM6, KEY_e, KEY_E):
            return 'turn_right', False
        if pressed(KEY_SPACE):
            return 'idle',       False

        return 'idle', False   # no key -> idle (stand still)

    # ---------------------------------------------------------------- #
    def _update_hud(self, direction: str, t: float):
        label = {
            'forward':    'FORWARD',
            'backward':   'BACKWARD',
            'crab_left':  'CRAB LEFT',
            'crab_right': 'CRAB RIGHT',
            'turn_left':  'TURN LEFT',
            'turn_right': 'TURN RIGHT',
            'idle':       'IDLE / STANDING',
        }.get(direction, direction.upper())

        try:
            self.p.addUserDebugText(
                f"{label}  |  t={t:.1f}s  |  ESC=quit",
                [0, 0, self.spawn_h + 0.20],
                textColorRGB=[0.2, 1.0, 0.2],
                textSize=1.4,
                replaceItemUniqueId=self.hud_id
            )
        except Exception:
            pass

    # ---------------------------------------------------------------- #
    def _is_connected(self) -> bool:
        try:
            return bool(self.p.getConnectionInfo()['isConnected'])
        except Exception:
            return False

    # ---------------------------------------------------------------- #
    def run(self):
        """
        Main loop. Runs indefinitely until ESC or window close.
        WASD / Arrow keys steer, SPACE stops, ESC quits.
        """
        p    = self.p
        dt   = 1.0 / 240.0   # physics timestep
        T    = 0.4            # gait cycle period [s]
        t    = 0.0
        step = 0

        # ---- Telemetry recording ----
        telemetry = Telemetry(params=self.params)

        # Settle into standing pose before gait starts
        print("  Settling into standing pose (2 seconds)...")
        self.stand()
        for _ in range(480):
            self.stand()   # keep enforcing pose
            p.stepSimulation()
            time.sleep(dt)
        print("  Ready — use ARROW KEYS or W/A/S/D/Q/E to move.\n")

        direction = 'idle'

        while True:
            loop_start = time.time()

            # Window closed?
            if not self._is_connected():
                print("  Window closed.")
                break

            # Read keyboard
            direction, quit_flag = self._read_keys()
            if quit_flag:
                print("  ESC pressed — quitting.")
                break

            # Apply gait or stand still
            if direction == 'idle':
                self.stand()
            else:
                self._gait_step(t, T, direction)

            # Step physics
            try:
                p.stepSimulation()
            except Exception:
                break

            # HUD update + telemetry recording every 48 steps (~5 Hz)
            if step % 48 == 0:
                self._update_hud(direction, t)
                telemetry.record(t, p, self.robot, self.joint_map, direction)

            # Real-time pacing
            elapsed = time.time() - loop_start
            remaining = dt - elapsed
            if remaining > 0:
                time.sleep(remaining)

            t    += dt
            step += 1

        # ---- Generate analytics dashboard ----
        print("  Generating analytics dashboard...")
        dashboard_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "hexapod_dashboard.png"
        )
        plot_dashboard(telemetry, save_path=dashboard_path)
        print(f"  Dashboard saved to: {dashboard_path}")

        try:
            p.disconnect()
        except Exception:
            pass
        print(f"  Simulation ended at t={t:.2f}s")


# ================================================================== #
#  KEYBOARD CONTROLLER (standalone wrapper)
# ================================================================== #

class HexapodKeyboardController:
    def __init__(self, params: HexapodParams):
        self.sim = HexapodSim(params, gui=True)

    def run_interactive(self):
        self.sim.run()


# ================================================================== #
#  ENTRY POINT
# ================================================================== #

def run_visualization(params: HexapodParams):
    # Matplotlib static pose (non-blocking)
    fig = plt.figure(figsize=(7, 6))
    ax  = fig.add_subplot(111, projection='3d')
    plot_static_pose(params, ax)
    plt.tight_layout()
    plt.show(block=False)
    plt.pause(0.5)

    print("\n--- PYBULLET SIMULATION ---")
    try:
        import pybullet       # noqa
        import pybullet_data  # noqa
        sim = HexapodSim(params, gui=True)
        sim.run()
    except ImportError:
        print("  PyBullet not installed. Run:  pip install pybullet")
    except Exception as e:
        import traceback
        print(f"  Simulation error: {e}")
        traceback.print_exc()
